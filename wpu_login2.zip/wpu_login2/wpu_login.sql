-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 25, 2019 at 02:43 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wpu_login`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `image` varchar(128) NOT NULL,
  `password` varchar(256) NOT NULL,
  `role_id` int(11) NOT NULL,
  `is_active` int(1) NOT NULL,
  `date_created` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `image`, `password`, `role_id`, `is_active`, `date_created`) VALUES
(8, 'alvenda', 'alfendadwiandini28@gmail.com', 'default.jpg', '$2y$10$nn2IXnWYSCVx3DUUwqBwh.MuVKYkNkmklRk6nNWNM1Uea.seiiqUe', 1, 1, 1567584750),
(9, 'ayun', 'ayun@gmail.com', 'profile1.jpg', '$2y$10$c0FYjGLdLe2/MjuETN58Ee1Vonds13UKdVJ6dILwgKBTUcrXeB8LC', 2, 1, 1567584872),
(18, 'ana', 'ana@gmail.com', 'default.jpg', '$2y$10$6oULQ3D8RPicep3x9ylM/OAM7WfeAPRqaiIhUeD3yjTEmX4bkptp2', 2, 1, 1568769695),
(19, 'ira', 'ira@gmail.com', 'default.jpg', '$2y$10$tSxdeEKp.rMoi7svAHpPIuf2RTTZlNzvy7jeyj2t36TqRq081BGvy', 2, 0, 1568771092),
(20, 'lala', 'lala@gmai.com', 'default.jpg', '$2y$10$UL9JQToHtGsI4SN71WS5huIfbZDcvrV8C1hSm3YamPKJb9ssLgfhW', 2, 0, 1569371471),
(21, 'ra', 'ra@gmial.com', 'default.jpg', '$2y$10$mzdXujGn6cFgscjpeJQ3Rew.Lv8OP.tdIE1GXBv1NEjgGZuSg0LWm', 2, 0, 1569371736),
(22, 'dwi', 'dwi@gmail.com', 'default.jpg', '$2y$10$zJuoqS6xCFL3k1oEXJCyveiALDJJtkMSk8X3aQhnocFXlxtBjz2um', 2, 1, 1569371797);

-- --------------------------------------------------------

--
-- Table structure for table `user_access_menu`
--

CREATE TABLE `user_access_menu` (
  `id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_access_menu`
--

INSERT INTO `user_access_menu` (`id`, `role_id`, `menu_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 2, 2),
(4, 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `user_menu`
--

CREATE TABLE `user_menu` (
  `id` int(11) NOT NULL,
  `menu` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_menu`
--

INSERT INTO `user_menu` (`id`, `menu`) VALUES
(1, 'Admin'),
(2, 'User'),
(3, 'Menu');

-- --------------------------------------------------------

--
-- Table structure for table `user_role`
--

CREATE TABLE `user_role` (
  `id` int(11) NOT NULL,
  `role` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_role`
--

INSERT INTO `user_role` (`id`, `role`) VALUES
(1, 'Administrator'),
(2, 'Member');

-- --------------------------------------------------------

--
-- Table structure for table `user_sub_menu`
--

CREATE TABLE `user_sub_menu` (
  `id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `title` varchar(128) NOT NULL,
  `url` varchar(128) NOT NULL,
  `icon` varchar(128) NOT NULL,
  `is_active` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_sub_menu`
--

INSERT INTO `user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon`, `is_active`) VALUES
(1, 1, 'Dashboard', 'Admin', 'fas fa-fw fa-tachometer-alt', 1),
(2, 2, 'My Profile', 'User', 'fas fa-fw fa-user', 1),
(3, 2, 'Edit profile', 'user/edit', 'fas fa-fw fa-user-edit', 1),
(4, 3, 'Menu Management', 'menu', 'fas fa-fw fa-folder', 1),
(5, 3, 'Submenu Management', 'menu/submenu', 'fas fa-fw fa-folder-open', 1),
(7, 1, 'Role', 'admin/role', 'fas fa-fw fa-user-tie', 1),
(8, 2, 'Change Password', 'user/changepassword', 'fas fa-fw fa-key', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_token`
--

CREATE TABLE `user_token` (
  `id` int(11) NOT NULL,
  `email` varchar(128) NOT NULL,
  `token` varchar(128) NOT NULL,
  `date_created` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_token`
--

INSERT INTO `user_token` (`id`, `email`, `token`, `date_created`) VALUES
(5, 'meta@gmail.com', 'B6lXDPvIRDXX9o4O33Vr7SYYIKqP6qqrES+DwjNoHsA=', 1568164173),
(7, 'dela@gmail.com', 'T1BxP6mitjQcO3wsdmoNFnpFNnw8v22a03Mmob22D0I=', 1568165515),
(8, 'nia@gmail.com', 'ZLZicwe93NIkqVBcxyVFJHZTAL5n1ERgo84Ts6KO9Y0=', 1568168929),
(9, 'fajar@gmail.com', '9gyyIQkc5Kn3xOUucSIey08LLmK0/U7YVsp9Sxj4z10=', 1568187293),
(10, 'fajar@gmail.com', '8WqDLTwzNZ2ZUPbjXP2nq5cmQRabS2EtRmBoW9zWvsg=', 1568188474),
(11, 'lala@gmai.com', 'SZAGHDgr7BR7r/OMEB23ms1SLaqNz/9L1uqti3nPoeY=', 1568189687),
(12, 'lala@gmai.com', 'wSYMWrNOPrKKHBmHWFNfECkT8/MMMk6GsND7MkVqffQ=', 1568606076),
(13, 'lili@gmail.com', 'Ru5SMokOpSeEGJjYjSUQ9DCFEDRl8WwZa5nhN+cme7A=', 1568606117),
(14, 'ayuny285@gmail.com', 'hW0t6ZUbpbU8MnrKhIwyVwPeOkwBlQqcv7xLezgRoW8=', 1568767801),
(16, 'nana@gmail.com', 'Is42ybvaBXh13pe/+qC90ZtJ/uyEElweMg4WZy0Y3kM=', 1568769226),
(17, 'lala@gmai.com', 'fDbXzfweUFnFmPjxaQhrO/X4CxHdFAWbfMla7OnWOCA=', 1568769391),
(19, 'ira@gmail.com', 'H70axIuVRQW0b1Ks2HRwcYyzeGtidNvIsCaSU7d+O7s=', 1568771092),
(20, 'ana@gmail.com', '0VA3UpSxMj06v9DdkPFQjeD81ELlpZXZkIsdUwnJ8fQ=', 1568772850),
(21, 'ana@gmail.com', 'uKYAuOSxDfSROr2ZNOV56YK6GS5KfmlhRzdZ9f5Ejds=', 1568773691),
(22, 'ana@gmail.com', 'g4GKs2Fy/aNloAQ1E6kq/VcAiLbS5IIMYwX+BR0eifE=', 1568774604),
(23, 'lala@gmai.com', 'vBMwUlVqtFkNfqPE9SUSG0W/UHVHOwMDO9sWCI7vo9E=', 1569371471),
(24, 'ra@gmial.com', 'yTRSNLt+nkgxroAVvy6x65HA04gEsruRUcE8k9cJSeA=', 1569371736),
(26, 'dwi@gmail.com', 'ExY3mfHcLyg9lcziTLdBiCuVFHpiKj9rrlRUHh9PKH0=', 1569371877);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_access_menu`
--
ALTER TABLE `user_access_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_menu`
--
ALTER TABLE `user_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_sub_menu`
--
ALTER TABLE `user_sub_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_token`
--
ALTER TABLE `user_token`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `user_access_menu`
--
ALTER TABLE `user_access_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user_menu`
--
ALTER TABLE `user_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user_role`
--
ALTER TABLE `user_role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user_sub_menu`
--
ALTER TABLE `user_sub_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user_token`
--
ALTER TABLE `user_token`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
